# ANALISI TRANSITORIA DI UN DECAY HEAT REMOVAL SYSTEM - PROPRIETA' COSTANTI (STUDIO DI CONVERGENZA NEL TEMPO)

from lbh15 import Lead 
import numpy as np
import matplotlib.pyplot as plt
import scipy.constants as const
import Sink

#--- FUNZIONI ---

#SORGENTE - Potenza termica legata al decadimento dei nuclidi ancora presenti 
def source(q0,time):

    qq=q0*0.0807*(time) ** (-0.229)
    
    return qq



#--- CORPO PRINCIPALE DELLO SCRIPT ---

# Liquid lead properties
Tmed = (400 + 480)/2 + 273
liquid_lead = Lead(T=Tmed)
lead_properties={"rho_Pb":liquid_lead.rho,
                 "cp_Pb":liquid_lead.cp,
                 "kk_Pb":liquid_lead.k,
                 "mu_Pb":float(liquid_lead.mu)}


# Reactor charateristics parameters
qq0 = 300*1e6 # [W] - Thermal nominal power 
TT0=440+273 # [K] - Initial conditions

# Geometry of the reactor
din = 8 # [m]
thick = 50e-3 # [m]
dout = din + 2*thick # [m]
LL = 10.13 # [m]
kk_vessel = 15 # [W/mK] - Vessel thermal conductivity 
eps_vessel = 0.45 # [] - Vessel emissivity 

Ain = din*np.pi*LL  # [m^2] - Internal exchange surface
Aout = dout*np.pi*LL # [m^2] - External exchange surface
Vol_lead = np.pi*LL*(din/2)**2 # [m^3]

vv = 1.12 #[m/s] - Lead speed

Geometry = {'Diameter in': din, 
            'Diameter out': dout, 
            'Thickness': thick, 
            'Length': LL, 
            'Area in': Ain,
              'Area out': Aout,
              "Epsilon":eps_vessel,
              "Lead volume":Vol_lead}


# Specific dimensionless numbers (Lead)
dimensionless_numbers=Sink.dimensionless(Geometry, lead_properties, vv)
hh_Pb = dimensionless_numbers["Nusselt"]*lead_properties["kk_Pb"]/LL


# External air and RVACS system
T_air = (30 + 100)/2 + 273  # [K] - Mean air temperature        
hh_air=Sink.coeff_conv_air(T_air,Tmed,LL)


# Global Heat Exchange coefficient computation
UU,RR=Sink.coeff_glob_sc(hh_Pb,Ain,dout/2,din/2,LL,50,hh_air,Aout)


TT = np.array([TT0]) #Lo definisco prima così nel dizionario riesco ad assegnare a T Lead l'ultimo valore di temperatura del vettore
                     #che servirà poi nella funziona Power_iter

Temperatures = {'T Lead': TT[-1], 'T inf': T_air}


#TRANSITORIO
dt_vect = np.array([1,10,50,100,250,500]) # [s]
err_dt = np.array([])
iterations=np.array([])

for jj in range(0,len(dt_vect)):

    dt=dt_vect[jj]
    tol = 1e-3
    err = 10*tol

    TT = np.array([TT0])

    time = [0]
    qq = np.array([0.04*qq0])


    Told = TT0
    ii = 0
    Tlim = 350 + 273

    while err > tol and ii<=1e5:
        ii += 1

        time.append(dt*ii)

        qq = np.append(qq,source(qq0,time[-1]))

        # Thermal power disposed (Convection with outside air + radiation between reactor vessel and RVACS)
        (T_vessel,P_conv,P_rad) = Sink.Power_iter(Geometry,Temperatures,UU,RR)
        
        # -- EULERO INDIETRO --

        hirr = Geometry.get("Epsilon") * const.Stefan_Boltzmann * Geometry.get("Area out") * (T_vessel**2 + Temperatures.get("T inf")**2 ) * (T_vessel + Temperatures.get("T inf")) #CONTINUIAMO CON IL VOCABOLARIO OPPURE RIPRENDIAMO DIRETTAMENTE LE VARIABILI???
        alpha = (UU * Geometry.get("Area out") + hirr)/(1 + hirr*(RR[0]+RR[1]))/(Geometry.get("Lead volume"))

        kk=dt/(lead_properties.get("rho_Pb")*lead_properties.get("cp_Pb"))
        Tnew = (Told + (qq[-1]/Geometry.get("Lead volume")+alpha*Temperatures.get("T inf"))*kk) / (1+alpha*kk )


        TT = np.append(TT,Tnew)

        Temperatures["T Lead"]=TT[-1]

        err = abs(Tnew-Tlim)/Tlim

        Told = Tnew
    
    if jj == 0 :
        T_rif = max(TT)
        dt_rif = dt
    
    else :
        T_max = max(TT)
        err_rel = abs(T_max-T_rif)/abs(T_rif)
        err_dt = np.append(err_dt,err_rel)
        iterations = np.append(iterations,ii)
        


#Plot dell'errore relativo
plt.rcParams.update({'font.size': 18})
plt.semilogy(dt_vect[1:],err_dt, marker='o', color='red', markersize=5, markeredgecolor='blue', label='Errore')
[plt.annotate( f"Δt={dt_vect[i]}  \n err={err_dt[i-1]:.2e}", xy=(dt_vect[i], err_dt[i-1]), xytext=(10, 1),textcoords='offset points', ha='left', va='bottom', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.3')) for i in range(1,len(dt_vect))]

plt.grid(True)
plt.xlabel('Δt [s]')
plt.ylabel('Errore relativo',fontweight='bold',fontsize=20)
plt.title('Studio di convergenza nel tempo',fontweight='bold',fontsize=20)
plt.show()



plt.plot(dt_vect[1:],iterations, marker='s', color='green', markersize=5, markeredgecolor='blue',label='Iterazioni')
[plt.annotate( f"Δt={dt_vect[i]}  \n it={iterations[i-1]:.2e}", xy=(dt_vect[i], iterations[i-1]), xytext=(10, 1.5),textcoords='offset points', ha='left', va='bottom', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.3')) for i in range(1,len(dt_vect))]

plt.grid(True)
plt.xlabel('Δt [s]')
plt.ylabel('Iterazioni',fontweight='bold',fontsize=20)
plt.title('Studio di convergenza nel tempo',fontweight='bold',fontsize=20)
plt.show()