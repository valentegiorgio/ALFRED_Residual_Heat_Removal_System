#ANALISI TRANSITORIA DI UN DECAY HEAT REMOVAL SYSTEM - PROPRIETA' NON COSTANTI

from lbh15 import Lead 
import numpy as np
import matplotlib.pyplot as plt
import scipy.constants as const
import Sink
import json


#SORGENTE - Potenza termica legata al decadimento dei nuclidi ancora presenti 
def source(q0,time):

    qq = q0 * 0.0807 * (time) ** (-0.229)
    
    return qq


Tmed = (400 + 480)/2 + 273

liquid_lead = Lead(T=Tmed)
lead_properties = {"rho_Pb":liquid_lead.rho,
                   "cp_Pb":liquid_lead.cp,
                   "kk_Pb":liquid_lead.k,
                   "mu_Pb":float(liquid_lead.mu)}


#--- MAIN BODY SCRIPT ---

# Reactor charateristics parameters
qq0 = 300*1e6 # [W] - Thermal nominal power 
TT0 = Tmed # [K] - Initial conditions

# Geometry of the reactor
din = 8 # [m]
thick = 50e-3 # [m]
dout = din + 2*thick # [m]
LL = 10.13 # [m]
kk_vessel = 15 # [W/mK] - Vessel thermal conductivity
eps_vessel = 0.45 # [] - Vessel emissivity

Ain = din*np.pi*LL  # [m^2] - Internal exchange surface
Aout = dout*np.pi*LL # [m^2] - External exchange surface
Vol_lead = np.pi*LL*(din/2)**2 # [m^3]

vv = 1.12 #[m/s] - Lead speed (CONSTANT)

Geometry = {'Diameter in': din, 
            'Diameter out': dout, 
            'Thickness': thick, 
            'Length': LL, 
            'Area in': Ain, 
            'Area out': Aout,
            'Epsilon': eps_vessel, 
            'Lead volume': Vol_lead}


# Specific dimensionless numbers (Lead)
dimensionless_numbers = Sink.dimensionless(Geometry, lead_properties, vv)
hh_Pb = dimensionless_numbers["Nusselt"] * lead_properties["kk_Pb"] / LL


# --- External air and RVACS system ---
T_air = (30 + 100)/2 + 273  # [K] - Mean air temperature
hh_air = Sink.coeff_conv_air(T_air,Tmed,LL)


# Global Heat Exchange coefficient computation
UU,RR = Sink.coeff_glob_sc(hh_Pb,Ain,dout/2,din/2,LL,50,hh_air,Aout)


TT = np.array([TT0]) #Lo definisco prima così nel dizionario riesco ad assegnare a T Lead l'ultimo valore di temperatura del vettore
                     #che servirà poi nella funziona Power_iter

Temperatures = {'T Lead': TT[-1], 'T inf': T_air}



#------ TRANSIENT IN TIME -------
dt = 100 # [s]
tol = 1e-5
err = 10*tol

time = [0]
qq = np.array([0.04*qq0])
starting = Sink.Power_iter(Geometry, Temperatures, UU, RR)
PP_conv = [starting[1]]
PP_rad = [starting[2]]
PP_dis = [PP_conv[0] + PP_rad[0]]


Told = TT0
ii = 0
Tlim = 350 + 273 # [K]

while err > tol and ii <= 1e4:
    ii += 1

    time.append(time[-1] + dt)

    qq = np.append(qq, source(qq0, time[-1]))

    Tvess_old, Pconv, Prad = Sink.Power_iter(Geometry,Temperatures,UU,RR)

    # frozen coefficient to calculate old properties of lead and air
    # ---- PROP NO CONST ----
    # LEAD:
    liquid_lead = Lead(T=Told)
    lead_properties = {"rho_Pb":liquid_lead.rho,
                       "cp_Pb":liquid_lead.cp,
                       "kk_Pb":liquid_lead.k,
                       "mu_Pb":float(liquid_lead.mu)}

    dimensionless_numbers = Sink.dimensionless(Geometry, lead_properties, vv)
    hh_Pb = dimensionless_numbers["Nusselt"] * lead_properties["kk_Pb"] / LL
    
    # AIR:
    hh_air = Sink.coeff_conv_air(T_air, Tvess_old, LL)

    UU, RR = Sink.coeff_glob_sc(hh_Pb,Ain,dout/2,din/2,LL,50,hh_air,Aout)


    # -- BACKWARD EULER --

    hirr = const.Stefan_Boltzmann * eps_vessel * Geometry.get('Area out') * (Tvess_old ** 2 + Temperatures.get('T inf') ** 2) * (Tvess_old + Temperatures.get('T inf'))

    cc = (UU * Geometry.get('Area out') + hirr) / (1 + hirr * (RR[0] + RR[1]))

    alpha = dt / (Geometry.get('Lead volume') * lead_properties.get('rho_Pb') * lead_properties.get('cp_Pb'))

    Tnew = (Told + (qq[-1] + cc * Temperatures.get('T inf')) * alpha) / (1 + cc * alpha)


    TT = np.append(TT, Tnew)

    err = abs(Tnew - Tlim) / Tnew

    Told = Tnew

    Temperatures['T Lead'] = TT[-1]


    # --- Power ---

    PP_conv.append(Pconv)
    PP_rad.append(Prad)
    PP_dis.append(Pconv + Prad)
    


time = np.asarray(time)


# --- RICOPIATURA DATI IN UN ALTRO FILE PER CONFRONTO ---

dati = {'Temperatura': TT.tolist(), 'Tempo': time.tolist()}

with open('PropNoConst.json', 'w') as file:
    json.dump(dati, file)



TTmax = max(TT)-273
imax = np.argmax(TT)

# --------------------------------------------------------

# PLOTS

# Lead temperature trend Plotted 
plt.figure(1)
plt.plot(time/3600, TT-273, label='Temperatura Pb')
plt.plot(time[imax]/3600, TTmax, marker='o', color='yellow', markersize=5, markeredgecolor='black', label='MAX Temperatura')
plt.plot(time/3600, 327*np.ones(len(TT)), color='red', linestyle='--', label='Solidificazione Pb')
plt.plot(time/3600, 550*np.ones(len(TT)), color='darkred', linestyle='-.', label='Limite strutturale')
plt.grid(True)
# y_ticks_custom = np.append(plt.yticks()[0], 327)
# plt.yticks(y_ticks_custom)
plt.xlabel('Tempo [h]')
plt.ylabel('Temperatura [°C]')
plt.title('Profilo di temperatura del piombo', fontweight='bold')
plt.legend(framealpha=1, bbox_to_anchor=(1, 0.9))
plt.tight_layout()
plt.show()


#Plot della sorgente e del pozzo in funzione del tempo
plt.figure(2)
plt.plot(time/3600, qq/1e6, color='red')
plt.xlabel('Tempo [h]')
plt.ylabel('Potenza [MW]')
plt.title('Potenza residua della sorgente', fontweight='bold')
plt.grid(True)
plt.show()


# Plot potenza dissipata
plt.figure(3)
plt.plot(time/3600, np.array(PP_dis)/1e6, label='Potenza totale')
plt.plot(time/3600, np.array(PP_conv)/1e6, linestyle='--', label='Convezione')
plt.plot(time/3600, np.array(PP_rad)/1e6, linestyle='--', label='Irraggiamento')
plt.xlabel('Tempo [h]')
plt.ylabel('Potenza [MW]')
plt.title('Potenza dispersa', fontweight='bold')
plt.legend()
plt.grid(True)

plt.figure(4)
plt.bar(['Convezione', 'Irraggiamento', 'Potenza totale'], np.asarray([PP_conv[imax], PP_rad[imax], PP_dis[imax]])/1e6, color=['green','green','darkred'], edgecolor='black')
plt.ylabel('Potenza [MW]')
plt.title('Potenza dispersa valutata alla temperatura MAX', fontweight='bold')
plt.show()


print(f'iterazioni: {ii}')
