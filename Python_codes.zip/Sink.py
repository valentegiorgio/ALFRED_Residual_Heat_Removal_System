import numpy as np
import scipy.constants as const
import matplotlib.pyplot as plt
from lbh15 import Lead
import cantera as ct


#----- PROBLEM WITH CONSTANT PROPERTIES -----

# LIQUID LEAD PROPERTIES
# Tmed = (400 + 480)/2 + 273    
# liquid_lead = Lead(T=Tmed)
# rho_Pb = liquid_lead.rho
# cp_Pb = liquid_lead.cp
# kk_Pb = liquid_lead.k
# mu_Pb = float(liquid_lead.mu)

# # GEOMETRY OF THE REACTOR
# din = 5 #m
# thick = 15e-3 #m
# dout = din + 2*thick #m
# LL = 10 #m

# Ain = din*np.pi*LL
# Aout = dout*np.pi*LL
# Vol_lead = np.pi*LL*(din/2)**2

# vv = 1 #m/s (velocità piombo)

def dimensionless(geometry,prop,vel):
    
    Re = prop.get('rho_Pb')*vel*geometry.get('Length')/prop.get('mu_Pb')
    Pr = float(prop.get('mu_Pb')*prop.get('cp_Pb')/prop.get('kk_Pb'))
    Pe = Re*Pr
    Nu = 5 + 0.025*(Pe)**(0.8) # SHIMAZAKI

    numbers = {"Reynolds":Re,"Prandtl":Pr,"Peclet":Pe,"Nusselt":Nu}
    return numbers


def coeff_conv_air(Tinf, Ts, lung):   
    # air properities
    air = ct.Solution('air.yaml')
    air.TP = (Tinf + Ts)/2, 101325

    rho = air.density       
    mu = air.viscosity
    nu = mu/rho
    cp = air.cp
    kk = air.thermal_conductivity
  
    alpha = kk/(rho*cp)
    beta = 1/Tinf  # ?

    Pr = nu/alpha

    # vertical plate

    Ra = (const.g*beta*(Ts - Tinf)*lung**3)/(nu*alpha)  # Rayleigh number
    Nu = (0.825 + (0.387 * (Ra)**(1/6))/((1 + (0.492/Pr)**(9/16))**(8/27)))**2

    hh = Nu*kk/lung

    # # cylinder

    # Ra2 = (const.g*beta*(Ts - T_air)*diam**3)/(nu*alpha)  # Rayleigh number
    # Nu2 = (0.60 + (0.387 * (Ra2)**(1/6))/((1 + (0.559/Pr)**(9/16))**(8/27)))**2

    # hh2 = Nu2*kk/diam

    return hh#, hh2

#hh_air = coeff_conv_air(T_air, Tmed, LL)  # NO Tmed


# ----- scambio termico -------

def coeff_glob_sc(hin, Ain, Rout, Rin, lung, kk, hout, Aout):

    if hin != 0:
        R_conv_in = 1/(hin*Ain)

    else:
        R_conv_in = 0
    
    if (isinstance(kk, list) and 
        isinstance(Rout, list) and
        isinstance(Rin, list) and
        len(kk) > 0 and len(Rout) > 0 and len(Rin) > 0):

        Rin = np.asarray(Rin)
        Rout = np.asarray(Rout)
        kk = np.asarray(kk)

        R_conduz = (np.log(Rout/Rin))/(2*np.pi*lung*kk)

    elif kk != 0:

        R_conduz = (np.log(Rout/Rin))/(2*np.pi*lung*kk)

    else:
        R_conduz = 0
            
    
    if hout != 0:
        R_conv_out = 1/(hout*Aout)

    else:
        R_conv_out = 0
    
    Rtot = R_conv_in + np.sum(R_conduz) + R_conv_out

    UU = 1/(Rtot*Aout)

    return UU, [R_conv_in, R_conduz, R_conv_out]


def PP_conv(UU, geom, temp):

    PP = UU * geom.get('Area out') * (temp.get('T Lead') - temp.get('T inf'))

    return PP

def PP_rad(geom, temp, Tv):

    PP = const.Stefan_Boltzmann * geom.get('Epsilon') * geom.get('Area out') * (Tv**4 - temp.get('T inf')**4)

    return PP



def Power_iter(geom, temp, UU, Res):

    # definizione potenze

    Res = np.asarray(Res)
    
    toll = 1e-3
    err = toll*10
    ii = 0
    Tguess = temp.get('T Lead') + 100

    Pconv = PP_conv(UU, geom, temp)
    

    while err > toll:
        ii += 1

        Prad = PP_rad(geom, temp, Tguess)
        P_dis = Pconv + Prad

        T_vess = temp.get('T Lead') - P_dis*(np.sum(Res[:2]))

        err = abs(Tguess - T_vess)/Tguess

        Tguess = T_vess
    
    Prad = PP_rad(geom, temp, T_vess)

    return T_vess, Pconv, Prad


